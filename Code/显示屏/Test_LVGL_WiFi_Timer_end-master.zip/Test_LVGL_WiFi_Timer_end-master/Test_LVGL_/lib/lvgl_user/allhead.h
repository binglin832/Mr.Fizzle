#ifndef _allhead_h_
#define _allhead_h_

#include "Arduino.h"
#include <TFT_eSPI.h>
#include "ui.h"
#include "lvgl_task.h"
#include "ui_task.h"
#include <FreeRTOSConfig.h>



#endif