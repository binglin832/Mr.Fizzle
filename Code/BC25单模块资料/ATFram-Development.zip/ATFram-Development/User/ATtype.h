#ifndef __ATTYPE_H_
#define __ATTYPE_H_

#include "stdint.h"

#define _ATCOMMANDNAMELIST CGSN,CSQ





#endif

