# ESP32_WIiFi_LVGL
esp32在TFT屏幕通过按键连接WiFi
1. 第一次提交 内容----LVGL-温湿度-时间-上传阿里云
2. 增加 Adafruit SGP30 Sensor@^2.0.2 库
    LVGL ui 增加 二氧化碳， TVOC 
    加入二氧化碳，TVOC显示及上传阿里云的业务代码