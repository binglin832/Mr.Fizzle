#ifndef __SOCKET_H_
#define	__SOCKET_H_

#include "AT.h"

ATStatus NetwoekInit(void);
ATStatus socket();

#endif
